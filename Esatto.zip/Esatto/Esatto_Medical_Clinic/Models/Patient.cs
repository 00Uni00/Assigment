﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Esatto_Medical_Clinic.Models
{
    public class Patient
    {
        public string PESEL { get; set; }
        public string FirstName { get; set; }   
        public string LastName { get; set; }
        public Address Address { get; set; }
    }
}
