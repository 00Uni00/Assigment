using Esatto_Medical_Clinic.Data;
using Esatto_Medical_Clinic.Interface;
using Esatto_Medical_Clinic.Repository;
using Esatto_Medical_Clinic.Seed;
using Microsoft.EntityFrameworkCore;

namespace Esatto_Medical_Clinic
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            builder.Services.AddControllersWithViews();
            builder.Services.AddScoped<IPatientRepository, PatientRepository>();

            builder.Services.AddDbContext<ClinicDbContext>(
                option => option.UseSqlServer(builder.Configuration.GetConnectionString("ClinicCS"))
                );
            var app = builder.Build();

            // Seeding
            using (var scope = app.Services.CreateScope()) 
            {
                var service = scope.ServiceProvider;
                var dbContext = service.GetRequiredService<ClinicDbContext>();
                PatientSeed.Seed(dbContext);
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Patient}/{action=Index}/{id?}");

            app.Run();
        }
    }
}