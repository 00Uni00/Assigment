﻿using System.ComponentModel.DataAnnotations;

namespace Esatto_Medical_Clinic.ViewModels
{
    public class CreatePatientViewModel
    {
        [Required(ErrorMessage = "PESEL is required.")]
        [RegularExpression(@"^\d{11}$", ErrorMessage = "PESEL must be 11 digits long.")]
        public string PESEL { get; set; }

        [Required(ErrorMessage = "First name is required.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last name is required.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Street is required.")]
        public string Street { get; set; }

        [Required(ErrorMessage = "City is required.")]
        public string City { get; set; }

        [Required(ErrorMessage = "Zip code is required.")]
        [RegularExpression(@"\d{2}-\d{3}", ErrorMessage = "Zip code must be in format '00-000'.")]
        public string ZipCode { get; set; }
    }
}
