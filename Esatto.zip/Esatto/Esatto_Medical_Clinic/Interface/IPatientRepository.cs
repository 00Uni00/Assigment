﻿using Esatto_Medical_Clinic.Models;

namespace Esatto_Medical_Clinic.Interface
{
    public interface IPatientRepository
    {
        Task<IEnumerable<Patient>> GetAllPatientsAsync();
        Task<IEnumerable<Patient>> FilterPatientByPeselAsync(string pesel);
        Task<Patient?> GetPatientByPeselAsync(string pesel);
        Task<Patient?> GetPatientByPeselNoTrackingAsync(string pesel);
        Task<bool> ExistsAsync(string pesel);
        bool Add(Patient patient);
        bool Delete(Patient patient);
        bool Update(Patient patient);
        bool Save();
    }
}
