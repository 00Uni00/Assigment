﻿using Esatto_Medical_Clinic.Interface;
using Esatto_Medical_Clinic.Models;
using Esatto_Medical_Clinic.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Update.Internal;

namespace Esatto_Medical_Clinic.Controllers
{
    public class PatientController : Controller
    {
        private readonly IPatientRepository _patientRepository;
        public PatientController(IPatientRepository patientRepository)
        {
            _patientRepository = patientRepository;
        }

        [HttpGet]
        public async Task<IActionResult> Index(int pageNumber)
        {
            IEnumerable<Patient> patients = await _patientRepository.GetAllPatientsAsync();
            return View(patients);
        }

        [HttpGet]
        public IActionResult Create() 
        {
            var patientVM = new CreatePatientViewModel();
            return View(patientVM);  
        }

        [HttpPost]
        public async Task<IActionResult> Create(CreatePatientViewModel patientVM)
        {
            if(ModelState.IsValid) 
            {
                if (await _patientRepository.ExistsAsync(patientVM.PESEL))
                {
                    ModelState.AddModelError("PESEL", "A patient with this PESEL already exists.");
                    return View(patientVM);
                }

                var patient = new Patient
                {
                    PESEL = patientVM.PESEL,
                    FirstName = patientVM.FirstName,
                    LastName = patientVM.LastName,
                    Address = new Address
                    {
                        Street = patientVM.Street,
                        City = patientVM.City,
                        ZipCode = patientVM.ZipCode,
                    }
                };
                _patientRepository.Add(patient);
                return RedirectToAction("Index");
            }
            return View(patientVM);
        }

        [HttpGet]
        public async Task<IActionResult> Update(string pesel)
        {
            var patient = await _patientRepository.GetPatientByPeselAsync(pesel);

            if (patient == null)
                return View("Error");

            var patientVM = new UpdatePatientViewModel()
            {
                IdAddress = patient.Address.Id,
                PESEL = patient.PESEL,
                FirstName = patient.FirstName,
                LastName = patient.LastName,
                Street = patient.Address.Street,
                ZipCode = patient.Address.ZipCode,
                City = patient.Address.City
            };

            return View(patientVM);
        }

        [HttpPost]
        public async Task<IActionResult> Update(string pesel ,UpdatePatientViewModel updateVM)
        {
            if (!ModelState.IsValid)
                return View("Update", updateVM);

            if (!await _patientRepository.ExistsAsync(updateVM.PESEL))
            {
                ModelState.AddModelError("PESEL", "A patient with this PESEL does not exists.");
                return View(updateVM);
            }

            var existingPatient = await _patientRepository.GetPatientByPeselAsync(pesel);

            if (existingPatient == null)
                return View("Error");

            existingPatient.FirstName = updateVM.FirstName;
            existingPatient.LastName = updateVM.LastName;

            existingPatient.Address.Street = updateVM.Street;
            existingPatient.Address.ZipCode = updateVM.ZipCode;
            existingPatient.Address.City = updateVM.City;

            _patientRepository.Update(existingPatient);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> Delete(string pesel) 
        {
            var patient = await _patientRepository.GetPatientByPeselAsync(pesel);

            if(patient == null)
                return View("Error");
            
            return View(patient); 
        }

        [HttpPost]
        public async Task<IActionResult> DeletePatient(string pesel) 
        {
            var patient = await _patientRepository.GetPatientByPeselNoTrackingAsync(pesel);
            if(patient == null)
                return View("Error");
             
            _patientRepository.Delete(patient);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public async Task<IActionResult> FilterPatients(string searchedPesel)
        {
            if(searchedPesel == null)
                return RedirectToAction("Index");

            var filterPesels = await _patientRepository.FilterPatientByPeselAsync(searchedPesel);

            if (filterPesels == null || !filterPesels.Any())
                return View("Index", new List<Patient>());
            
            return View("Index", filterPesels);
        }
    }
}