﻿using Esatto_Medical_Clinic.Data;
using Esatto_Medical_Clinic.Interface;
using Esatto_Medical_Clinic.Models;
using Microsoft.EntityFrameworkCore;

namespace Esatto_Medical_Clinic.Repository
{
    public class PatientRepository : IPatientRepository
    {
        private readonly ClinicDbContext _context;
        public PatientRepository(ClinicDbContext context)
        {
            _context = context;
        }
        public async Task<IEnumerable<Patient>> GetAllPatientsAsync() 
        {
            return await _context.Patients
                .Include(p => p.Address)
                .ToListAsync();
        }
        public async Task<Patient> GetPatientByPeselAsync(string pesel) 
        {
            return await _context.Patients
                .Include(p => p.Address)
                .FirstOrDefaultAsync(p => p.PESEL == pesel);
        }

        public async Task<IEnumerable<Patient>> FilterPatientByPeselAsync(string pesel)
        {
            var patients = await GetAllPatientsAsync();

            return patients.Where(p => p.PESEL.Contains(pesel)).ToList();
        }

        public async Task<Patient?> GetPatientByPeselNoTrackingAsync(string pesel)
        {
            return await _context.Patients
                .Include(p => p.Address)
                .FirstOrDefaultAsync(p => p.PESEL == pesel);
        }
        public async Task<bool> ExistsAsync(string pesel)
        {
            return await _context.Patients.AnyAsync(p => p.PESEL == pesel);
        }

        public bool Add(Patient patient) 
        {
            _context.Add(patient);
            return Save();
        }

        public bool Delete(Patient patient) 
        {
            _context.Remove(patient);
            return Save();  
        }

        public bool Update(Patient patient) 
        { 
            _context.Update(patient);
            return Save();
        }

        public bool Save() 
        {
            var saved = _context.SaveChanges();
            return saved > 0;
        }
    }
}
