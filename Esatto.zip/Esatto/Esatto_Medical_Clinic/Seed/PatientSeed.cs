﻿using Esatto_Medical_Clinic.Data;
using Esatto_Medical_Clinic.Models;

namespace Esatto_Medical_Clinic.Seed
{
    public static class PatientSeed
    {
        public static void Seed(ClinicDbContext context)
        {
            context.Database.EnsureCreated();

            if (context.Patients.Any())
                return;

            var patients = GeneratePatients();
            context.Patients.AddRange(patients);
            context.SaveChanges();

        }

        private static List<Patient> GeneratePatients() 
        {
            var patients = new List<Patient>
            {
                new Patient { 
                    PESEL = "32409842188", 
                    FirstName = "John", 
                    LastName = "Doe", 
                    Address = new Address
                    {
                        Street = "123 Main St",
                        City = "Anytown",
                        ZipCode = "12-345"
                    },
                },

                new Patient { 
                    PESEL = "14819205978", 
                    FirstName = "Jane", 
                    LastName = "Smith" ,
                    Address = new Address
                    {
                        Street = "456 Elm St",
                        City = "Othertown",
                        ZipCode = "54-321"
                    },
                },

                new Patient { 
                    PESEL = "81735091571", 
                    FirstName = "Michael", 
                    LastName = "Johnson",
                    Address = new Address
                    {
                        Street = "789 Oak St",
                        City = "Smallville",
                        ZipCode = "98-765"
                    },
                },

                new Patient {
                    PESEL = "19304811093",
                    FirstName = "Emily",
                    LastName = "Brown",
                    Address =  new Address
                    {
                        Street = "321 Pine St",
                        City = "Villageton",
                        ZipCode = "65-432"
                    },
                },

                new Patient {
                    PESEL = "43579110231",
                    FirstName = "William",
                    LastName = "Taylor",
                    Address = new Address
                    { 
                        Street = "555 Cedar St",
                        City = "Ruraltown",
                        ZipCode = "78-901"
                    },
                },

                new Patient {
                    PESEL = "14298401128",
                    FirstName = "Olivia",
                    LastName = "Anderson",
                    Address = new Address
                    {
                        Street = "777 Maple St",
                        City = "Cityville",
                        ZipCode = "10-987"
                    },
                },

                new Patient {
                    PESEL = "59380510232",
                    FirstName = "Daniel",
                    LastName = "Martinez",
                    Address = new Address
                    {
                        Street = "222 Pineapple St",
                        City = "Beachtown",
                        ZipCode = "45-678"
                    }
                },

                new Patient {
                    PESEL = "32958028133",
                    FirstName = "Sophia",
                    LastName = "Wilson",
                    Address = new Address
                    {
                        Street = "888 Birch St",
                        City = "Metropolis",
                        ZipCode = "11-112"
                    },
                },

                new Patient {
                    PESEL = "34280231948",
                    FirstName = "Matthew",
                    LastName = "Garcia",
                    Address = new Address
                    {
                        Street = "999 Walnut St",
                        City = "Suburbia",
                        ZipCode = "23-456"
                    },
                },

                new Patient {
                    PESEL = "86109128324",
                    FirstName = "Emma",
                    LastName = "Jones", 
                    Address = new Address
                    {
                        Street = "444 Ash St",
                        City = "Hamletville",
                        ZipCode = "34-789"
                    },
                }
            };
            
            return patients;
        }
    }
}
