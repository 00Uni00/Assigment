﻿using Esatto_Medical_Clinic.Models;
using Microsoft.EntityFrameworkCore;

namespace Esatto_Medical_Clinic.Data
{
    public class ClinicDbContext : DbContext
    {
        public ClinicDbContext(DbContextOptions<ClinicDbContext> options) : base(options)
        {

        }

        public DbSet<Patient> Patients { get; set; }
        public DbSet<Address> Addresses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Patient>(p =>
            {
                p.HasKey(pe => pe.PESEL);

                p.Property(p => p.FirstName)
                    .IsRequired();

                p.Property(p => p.LastName)
                    .IsRequired();

                p.HasOne(pe => pe.Address)
                    .WithOne(a => a.Patient)
                    .HasForeignKey<Address>(a => a.PatientPESEL);
            });

            modelBuilder.Entity<Address>(a =>
            {
                a.HasOne(a => a.Patient)
                  .WithOne(ad => ad.Address)
                  .HasForeignKey<Address>(a => a.PatientPESEL);

                a.Property(a => a.Street)
                    .IsRequired();
                
                a.Property(a => a.City)
                    .IsRequired();

                a.Property(a => a.ZipCode)
                    .IsRequired()
                    .HasMaxLength(6)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasColumnType("char");
            });
        }
    }
}
